import { type Page, type Lang } from '../App'

interface Props {
  navigate: (page: Page) => void
  lang: Lang
}

const t = {
  ENG: {
    tagline: 'Crafting immersive visual experiences that transform ideas into breathtaking realities.',
    services: 'Services',
    company: 'Company',
    contact: 'Contact',
    address: '194 Nguyễn Mậu Tài - Hòa Xuân - Đà Nẵng',
    email: 'hello@sensia3d.vn',
    phone: '+84 28 3822 4488',
    copyright: '© 2026 SENSIA3D. All rights reserved.',
    links: {
      services: ['3D Rendering', 'VR Tour', '3D Mapping', '3D Modeling', 'AR Experience'],
      company: ['About Us', 'Projects', 'Blog', 'Careers', 'Contact'],
    },
  },
  VIE: {
    tagline: 'Tạo ra những trải nghiệm thị giác đắm chìm biến ý tưởng thành những thực tế tuyệt vời.',
    services: 'Dịch Vụ',
    company: 'Công Ty',
    contact: 'Liên Hệ',
    address: '12 Nguyễn Huệ, Quận 1\nTP. Hồ Chí Minh, Việt Nam',
    email: 'hello@sensia3d.vn',
    phone: '+84 28 3822 4488',
    copyright: '© 2026 SENSIA3D. Tất cả quyền được bảo lưu.',
    links: {
      services: ['Kết Xuất 3D', 'Tour VR', '3D Mapping', 'Mô Hình 3D', 'Trải Nghiệm AR'],
      company: ['Về Chúng Tôi', 'Dự Án', 'Blog', 'Tuyển Dụng', 'Liên Hệ'],
    },
  },
}

const servicePages: Page[] = ['services', 'services', 'services', 'services', 'services']
const companyPages: Page[] = ['about', 'projects', 'blog', 'about', 'about']

export default function Footer({ navigate, lang }: Props) {
  const tx = t[lang]

  return (
    <footer className="bg-[#060D1A] border-t border-white/5">
      <div className="max-w-[1400px] mx-auto px-6 md:px-12 py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand */}
          <div className="lg:col-span-1">
            <button onClick={() => navigate('home')} className="flex items-center gap-3 mb-5 group">
              <div className="relative w-9 h-9">
                <div className="absolute inset-0 rounded-lg bg-gradient-to-br from-[#00D9FF] to-[#3B82F6] opacity-20 group-hover:opacity-40 transition-opacity" />
                <div className="absolute inset-[2px] rounded-[6px] bg-[#060D1A] flex items-center justify-center">
                  <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                    <polygon points="10,2 18,7 18,13 10,18 2,13 2,7" stroke="#00D9FF" strokeWidth="1.2" fill="none" />
                    <polygon points="10,5 15,8 15,12 10,15 5,12 5,8" fill="rgba(0,217,255,0.15)" stroke="#00D9FF" strokeWidth="0.6" />
                    <circle cx="10" cy="10" r="1.5" fill="#00D9FF" />
                  </svg>
                </div>
              </div>
              <span className="font-display font-800 text-[17px] tracking-wide text-white">
                SENSIA<span className="text-[#00D9FF]">3D</span>
              </span>
            </button>
            <p className="text-white/40 text-sm leading-relaxed mb-8">{tx.tagline}</p>
            <div className="flex gap-4">
              {['linkedin', 'instagram', 'youtube', 'behance'].map((social) => (
                <div
                  key={social}
                  className="w-9 h-9 rounded-lg glass-light border border-white/8 flex items-center justify-center text-white/30 hover:text-[#00D9FF] hover:border-[#00D9FF]/30 transition-all cursor-pointer text-xs font-mono uppercase"
                >
                  {social[0].toUpperCase()}
                </div>
              ))}
            </div>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-display font-bold text-white text-sm mb-5 tracking-wide">{tx.services}</h4>
            <ul className="flex flex-col gap-3">
              {tx.links.services.map((link, i) => (
                <li key={i}>
                  <button
                    onClick={() => navigate(servicePages[i])}
                    className="text-white/40 text-sm hover:text-white transition-colors"
                  >
                    {link}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="font-display font-bold text-white text-sm mb-5 tracking-wide">{tx.company}</h4>
            <ul className="flex flex-col gap-3">
              {tx.links.company.map((link, i) => (
                <li key={i}>
                  <button
                    onClick={() => navigate(companyPages[i])}
                    className="text-white/40 text-sm hover:text-white transition-colors"
                  >
                    {link}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-display font-bold text-white text-sm mb-5 tracking-wide">{tx.contact}</h4>
            <div className="flex flex-col gap-4 text-sm text-white/40">
              <div>
                <p className="whitespace-pre-line leading-relaxed">{tx.address}</p>
              </div>
              <a href={`mailto:${tx.email}`} className="hover:text-[#00D9FF] transition-colors">{tx.email}</a>
              <a href={`tel:${tx.phone}`} className="hover:text-white transition-colors font-mono">{tx.phone}</a>
            </div>
          </div>
        </div>

        <div className="mt-16 pt-8 border-t border-white/5 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-white/25 text-xs font-mono">{tx.copyright}</p>
          <div className="flex gap-6 text-white/25 text-xs">
            <span className="hover:text-white cursor-pointer transition-colors">Privacy Policy</span>
            <span className="hover:text-white cursor-pointer transition-colors">Terms of Service</span>
          </div>
        </div>
      </div>
    </footer>
  )
}
