import { type Page, type Lang } from '../App'

interface Props {
  currentPage: Page
  navigate: (page: Page) => void
  lang: Lang
  setLang: (l: Lang) => void
  menuOpen: boolean
  setMenuOpen: (v: boolean) => void
  scrolled: boolean
}

const t = {
  ENG: {
    about: 'About Us',
    services: 'Services',
    projects: 'Projects',
    blog: 'Blog',
  },
  VIE: {
    about: 'Về Chúng Tôi',
    services: 'Dịch Vụ',
    projects: 'Dự Án',
    blog: 'Blog',
  },
}

const pages: Page[] = ['about', 'services', 'projects', 'blog']

export default function Navigation({ currentPage, navigate, lang, setLang, menuOpen, setMenuOpen, scrolled }: Props) {
  const labels = t[lang]

  return (
    <>
      <header
        className="fixed top-0 left-0 right-0 z-50 transition-all duration-500"
        style={{
          background: scrolled
            ? 'rgba(18, 13, 10, 0.90)'
            : 'transparent',
          backdropFilter: scrolled ? 'blur(20px)' : 'none',
          borderBottom: scrolled ? '1px solid rgba(255, 107, 0, 0.15)' : 'none',
        }}
      >
        <div className="max-w-[1400px] mx-auto px-6 md:px-12 h-[72px] flex items-center justify-between">
          {/* Logo TAV - Nút quay về HomePage */}
          <button
            onClick={() => navigate('home')}
            className="flex items-center gap-3 group"
          >
            <div className="relative w-9 h-9">
              <div className="absolute inset-0 rounded-lg bg-gradient-to-br from-[#FF9E00] to-[#FF6B00] opacity-20 group-hover:opacity-40 transition-opacity" />
              <div className="absolute inset-[2px] rounded-[6px] bg-[#1A120C] flex items-center justify-center">
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                  <polygon points="10,2 18,7 18,13 10,18 2,13 2,7" stroke="#FF6B00" strokeWidth="1.2" fill="none" />
                  <polygon points="10,5 15,8 15,12 10,15 5,12 5,8" fill="rgba(255,107,0,0.15)" stroke="#FF6B00" strokeWidth="0.6" />
                  <circle cx="10" cy="10" r="1.5" fill="#FF9E00" />
                </svg>
              </div>
            </div>
            <span className="font-display font-extrabold text-[20px] tracking-wider text-white">
              T<span className="text-[#FF6B00]">AV</span>
            </span>
          </button>

          {/* Desktop nav */}
          <nav className="hidden md:flex items-center gap-8">
            {pages.map((page) => (
              <button
                key={page}
                onClick={() => navigate(page)}
                className={`nav-link text-sm font-medium tracking-wide ${currentPage === page ? 'text-white font-semibold' : 'text-white/70 hover:text-white'}`}
                style={currentPage === page ? { color: '#FF9E00' } : {}}
              >
                {labels[page as keyof typeof labels]}
              </button>
            ))}
          </nav>

          {/* Right side */}
          <div className="flex items-center gap-4">
            {/* Lang switch */}
            <div className="hidden md:flex items-center gap-1 font-mono text-xs">
              <button
                onClick={() => setLang('VIE')}
                className={`px-2 py-1 rounded transition-colors ${lang === 'VIE' ? 'text-[#FF9E00] font-bold' : 'text-white/40 hover:text-white/80'}`}
              >
                VIE
              </button>
              <span className="text-white/20">|</span>
              <button
                onClick={() => setLang('ENG')}
                className={`px-2 py-1 rounded transition-colors ${lang === 'ENG' ? 'text-[#FF9E00] font-bold' : 'text-white/40 hover:text-white/80'}`}
              >
                ENG
              </button>
            </div>

            {/* Hamburger */}
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="relative w-10 h-10 flex flex-col justify-center items-center gap-[5px] group"
              aria-label="Toggle menu"
            >
              <span
                className="hamburger-line block w-6 h-[1.5px] bg-white origin-center"
                style={{
                  transform: menuOpen ? 'translateY(6.5px) rotate(45deg)' : 'none',
                }}
              />
              <span
                className="hamburger-line block w-6 h-[1.5px] bg-white"
                style={{ opacity: menuOpen ? 0 : 1 }}
              />
              <span
                className="hamburger-line block w-6 h-[1.5px] bg-white origin-center"
                style={{
                  transform: menuOpen ? 'translateY(-6.5px) rotate(-45deg)' : 'none',
                }}
              />
            </button>
          </div>
        </div>
      </header>

      {/* Full-screen mobile / overlay menu */}
      <div
        className="fixed inset-0 z-40 mobile-menu"
        style={{
          transform: menuOpen ? 'translateX(0)' : 'translateX(100%)',
          opacity: menuOpen ? 1 : 0,
          pointerEvents: menuOpen ? 'auto' : 'none',
          background: 'rgba(18, 13, 10, 0.98)',
          backdropFilter: 'blur(24px)',
        }}
      >
        <div className="flex flex-col justify-center items-center h-full gap-8">
          {pages.map((page, i) => (
            <button
              key={page}
              onClick={() => navigate(page)}
              className={`font-display text-4xl md:text-5xl font-bold tracking-tight transition-colors ${currentPage === page ? 'text-[#FF9E00]' : 'text-white/80 hover:text-white'}`}
              style={{
                transitionDelay: menuOpen ? `${i * 60}ms` : '0ms',
              }}
            >
              {labels[page as keyof typeof labels]}
            </button>
          ))}

          <div className="mt-6 flex items-center gap-3 font-mono text-sm">
            <button
              onClick={() => setLang('VIE')}
              className={`px-4 py-2 rounded-md border transition-all ${lang === 'VIE' ? 'border-[#FF6B00] text-[#FF9E00] bg-[#FF6B00]/10' : 'border-white/20 text-white/40'}`}
            >
              VIE
            </button>
            <button
              onClick={() => setLang('ENG')}
              className={`px-4 py-2 rounded-md border transition-all ${lang === 'ENG' ? 'border-[#FF6B00] text-[#FF9E00] bg-[#FF6B00]/10' : 'border-white/20 text-white/40'}`}
            >
              ENG
            </button>
          </div>
        </div>
      </div>
    </>
  )
}