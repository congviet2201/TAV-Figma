import { useEffect, useRef, useState } from 'react'
import { type Page, type Lang } from '../App'

interface Props {
  navigate: (page: Page) => void
  lang: Lang
}

const t = {
  ENG: {
    tagline: 'Immersive 3D Visualization',
    headline1: 'We Build Worlds',
    headline2: 'Before They Exist',
    sub: 'Premium 3D rendering, architectural visualization, and immersive technology solutions that transform ideas into extraordinary experiences.',
    cta1: 'Explore Our Work',
    cta2: 'Our Services',
    statsLabel1: 'Projects Delivered',
    statsLabel2: 'Years of Excellence',
    statsLabel3: 'Global Clients',
    statsLabel4: 'Awards Won',
    servicesTitle: 'What We Do',
    servicesHeadline: 'End-to-End Immersive Solutions',
    projectsTitle: 'Featured Work',
    projectsHeadline: 'Projects That Define Us',
    viewAll: 'View All Projects',
    contactTitle: 'Ready to Collaborate?',
    contactSub: "Let's build something extraordinary together.",
    contactCta: 'Get In Touch',
  },
  VIE: {
    tagline: 'Trực Quan Hóa 3D Đắm Chìm',
    headline1: 'Chúng Tôi Xây Dựng',
    headline2: 'Thế Giới Trước Khi Chúng Tồn Tại',
    sub: 'Giải pháp kết xuất 3D, trực quan hóa kiến trúc và công nghệ đắm chìm cao cấp, biến ý tưởng thành những trải nghiệm phi thường.',
    cta1: 'Khám Phá Công Trình',
    cta2: 'Dịch Vụ Của Chúng Tôi',
    statsLabel1: 'Dự Án Hoàn Thành',
    statsLabel2: 'Năm Xuất Sắc',
    statsLabel3: 'Khách Hàng Toàn Cầu',
    statsLabel4: 'Giải Thưởng',
    servicesTitle: 'Chúng Tôi Làm Gì',
    servicesHeadline: 'Giải Pháp Toàn Diện',
    projectsTitle: 'Công Trình Nổi Bật',
    projectsHeadline: 'Những Dự Án Định Nghĩa Chúng Tôi',
    viewAll: 'Xem Tất Cả Dự Án',
    contactTitle: 'Sẵn Sàng Hợp Tác?',
    contactSub: 'Hãy cùng xây dựng điều phi thường.',
    contactCta: 'Liên Hệ Ngay',
  },
}

const stats = [
  { value: '350+', key: 'statsLabel1' },
  { value: '12', key: 'statsLabel2' },
  { value: '80+', key: 'statsLabel3' },
  { value: '24', key: 'statsLabel4' },
]

const services = [
  {
    icon: (
      <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
        <path d="M14 3L25 9.5V18.5L14 25L3 18.5V9.5L14 3Z" stroke="#00D9FF" strokeWidth="1.5" fill="rgba(0,217,255,0.08)" />
        <path d="M14 8L20 11.5V18L14 21.5L8 18V11.5L14 8Z" stroke="#00D9FF" strokeWidth="0.8" fill="rgba(0,217,255,0.12)" />
        <circle cx="14" cy="14" r="2" fill="#00D9FF" />
      </svg>
    ),
    titleENG: '3D Rendering',
    titleVIE: 'Kết Xuất 3D',
    descENG: 'Photorealistic renders that bring architecture and design to life with stunning accuracy.',
    descVIE: 'Hình ảnh siêu thực mang kiến trúc và thiết kế sống động với độ chính xác tuyệt vời.',
  },
  {
    icon: (
      <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
        <circle cx="14" cy="14" r="10" stroke="#3B82F6" strokeWidth="1.5" fill="rgba(59,130,246,0.08)" />
        <ellipse cx="14" cy="14" rx="10" ry="4" stroke="#3B82F6" strokeWidth="0.8" fill="none" />
        <line x1="14" y1="4" x2="14" y2="24" stroke="#3B82F6" strokeWidth="0.8" />
        <circle cx="14" cy="14" r="2" fill="#3B82F6" />
      </svg>
    ),
    titleENG: '3D Mapping',
    titleVIE: '3D Mapping',
    descENG: 'Large-scale projection mapping that transforms surfaces into immersive visual canvases.',
    descVIE: 'Chiếu hình ảnh quy mô lớn biến bề mặt thành những tấm canvas trực quan đắm chìm.',
  },
  {
    icon: (
      <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
        <rect x="4" y="8" width="8" height="12" rx="1" stroke="#00D9FF" strokeWidth="1.2" fill="rgba(0,217,255,0.08)" />
        <rect x="16" y="4" width="8" height="8" rx="1" stroke="#00D9FF" strokeWidth="1.2" fill="rgba(0,217,255,0.08)" />
        <rect x="16" y="16" width="8" height="8" rx="1" stroke="#00D9FF" strokeWidth="1.2" fill="rgba(0,217,255,0.08)" />
        <line x1="12" y1="12" x2="16" y2="8" stroke="#00D9FF" strokeWidth="0.8" strokeDasharray="2 2" />
        <line x1="12" y1="16" x2="16" y2="20" stroke="#00D9FF" strokeWidth="0.8" strokeDasharray="2 2" />
      </svg>
    ),
    titleENG: '3D Modeling',
    titleVIE: 'Mô Hình 3D',
    descENG: 'Precision 3D models built from scratch or converted from existing blueprints and plans.',
    descVIE: 'Mô hình 3D chính xác xây dựng từ đầu hoặc chuyển đổi từ bản vẽ và kế hoạch hiện có.',
  },
  {
    icon: (
      <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
        <rect x="3" y="10" width="22" height="14" rx="3" stroke="#8B5CF6" strokeWidth="1.5" fill="rgba(139,92,246,0.08)" />
        <path d="M9 10V8a5 5 0 0 1 10 0v2" stroke="#8B5CF6" strokeWidth="1.2" fill="none" />
        <circle cx="14" cy="17" r="2.5" fill="#8B5CF6" fillOpacity="0.6" stroke="#8B5CF6" strokeWidth="0.8" />
      </svg>
    ),
    titleENG: 'VR Tour',
    titleVIE: 'Tour VR',
    descENG: 'Fully interactive virtual reality experiences for real estate, hospitality, and retail.',
    descVIE: 'Trải nghiệm thực tế ảo tương tác hoàn toàn cho bất động sản, khách sạn và bán lẻ.',
  },
  {
    icon: (
      <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
        <circle cx="14" cy="14" r="6" stroke="#00D9FF" strokeWidth="1.5" fill="rgba(0,217,255,0.08)" />
        <path d="M8 8L5 5M20 8L23 5M8 20L5 23M20 20L23 23" stroke="#00D9FF" strokeWidth="1.2" strokeLinecap="round" />
        <circle cx="14" cy="14" r="2" fill="#00D9FF" />
        <path d="M14 8V6M14 20v2M8 14H6M20 14h2" stroke="#00D9FF" strokeWidth="0.8" />
      </svg>
    ),
    titleENG: 'AR Experience',
    titleVIE: 'Trải Nghiệm AR',
    descENG: 'Augmented reality overlays that let clients visualize spaces and products in the real world.',
    descVIE: 'Lớp phủ thực tế tăng cường cho phép khách hàng hình dung không gian và sản phẩm trong thế giới thực.',
  },
]

const featuredProjects = [
  {
    title: 'The SENSIA',
    category: 'Architectural Visualization',
    img: 'https://images.unsplash.com/photo-1678388583153-f0e667c97288?w=800&h=600&fit=crop&auto=format',
    span: 'large',
  },
  {
    title: 'Da Song Village',
    category: '3D Rendering',
    img: 'https://images.unsplash.com/photo-1633109713362-031e75973c1b?w=600&h=500&fit=crop&auto=format',
    span: 'small',
  },
  {
    title: 'Diamond Island',
    category: 'VR Tour',
    img: 'https://images.unsplash.com/photo-1682184805271-11671b7ecf4c?w=600&h=500&fit=crop&auto=format',
    span: 'small',
  },
]

export default function HomePage({ navigate, lang }: Props) {
  const tx = t[lang]
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => setVisible(true), 100)
    return () => clearTimeout(timer)
  }, [])

  return (
    <>
      {/* ── HERO ── */}
      <section className="relative w-full h-screen min-h-[600px] overflow-hidden">
        {/* Video BG */}
        <div className="absolute inset-0 bg-[#0B1120]">
          <img
            src="https://images.unsplash.com/photo-1678388583153-f0e667c97288?w=1920&h=1080&fit=crop&auto=format"
            alt="3D visualization hero"
            className="w-full h-full object-cover opacity-35"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-[#0B1120]/60 via-transparent to-[#0B1120]" />
          <div className="absolute inset-0 grid-overlay" />
          <div className="absolute inset-0 noise" />
        </div>

        {/* Floating orbs */}
        <div className="absolute top-1/4 right-1/4 w-[500px] h-[500px] rounded-full opacity-10 animate-float"
          style={{ background: 'radial-gradient(circle, #00D9FF 0%, transparent 70%)' }} />
        <div className="absolute bottom-1/3 left-1/3 w-[400px] h-[400px] rounded-full opacity-8 animate-float"
          style={{ background: 'radial-gradient(circle, #3B82F6 0%, transparent 70%)', animationDelay: '2s' }} />

        {/* Rotating ring */}
        <div className="absolute top-1/2 right-16 -translate-y-1/2 hidden lg:block">
          <div className="w-[260px] h-[260px] animate-spin-slow">
            <svg width="260" height="260" viewBox="0 0 260 260" fill="none">
              <circle cx="130" cy="130" r="120" stroke="rgba(0,217,255,0.15)" strokeWidth="1" strokeDasharray="8 4" />
              <circle cx="130" cy="130" r="90" stroke="rgba(59,130,246,0.1)" strokeWidth="1" strokeDasharray="4 8" />
              <circle cx="130" cy="10" r="4" fill="#00D9FF" />
              <circle cx="130" cy="130" r="60" stroke="rgba(0,217,255,0.06)" strokeWidth="1" />
            </svg>
          </div>
        </div>

        {/* Hero content */}
        <div className="relative z-10 flex flex-col justify-center h-full max-w-[1400px] mx-auto px-6 md:px-12">
          <div className={`transition-all duration-1000 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            <div className="section-label mb-6 animate-fade-in-up animate-delay-100">
              ◆ {tx.tagline}
            </div>
            <h1 className="font-display font-bold leading-[1.0] mb-6">
              <span
                className="block text-[clamp(3rem,7vw,6.5rem)] text-white animate-fade-in-up animate-delay-200"
              >
                {tx.headline1}
              </span>
              <span
                className="block text-[clamp(3rem,7vw,6.5rem)] text-gradient animate-fade-in-up animate-delay-300"
              >
                {tx.headline2}
              </span>
            </h1>
            <p className="max-w-[520px] text-[#94A3B8] text-lg leading-relaxed mb-10 animate-fade-in-up animate-delay-400">
              {tx.sub}
            </p>
            <div className="flex flex-wrap gap-4 animate-fade-in-up animate-delay-500">
              <button
                onClick={() => navigate('projects')}
                className="btn-primary px-8 py-4 text-sm font-display font-bold tracking-wide"
              >
                {tx.cta1}
              </button>
              <button
                onClick={() => navigate('services')}
                className="btn-outline px-8 py-4 text-sm"
              >
                {tx.cta2}
              </button>
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 animate-pulse-glow">
          <span className="font-mono text-[10px] tracking-widest text-white/30 uppercase">Scroll</span>
          <div className="w-[1px] h-10 bg-gradient-to-b from-[#00D9FF]/50 to-transparent" />
        </div>
      </section>

      {/* ── STATS ── */}
      <section className="py-20 border-y border-white/5">
        <div className="max-w-[1400px] mx-auto px-6 md:px-12">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((s) => (
              <div key={s.key} className="text-center">
                <div className="font-display text-5xl md:text-6xl font-bold text-gradient mb-2">{s.value}</div>
                <div className="font-mono text-xs tracking-widest text-white/40 uppercase">{tx[s.key as keyof typeof tx]}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── SERVICES PREVIEW ── */}
      <section className="py-28">
        <div className="max-w-[1400px] mx-auto px-6 md:px-12">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
            <div>
              <div className="section-label mb-4">◆ {tx.servicesTitle}</div>
              <h2 className="font-display text-4xl md:text-5xl font-bold text-white leading-tight">
                {tx.servicesHeadline}
              </h2>
            </div>
            <button
              onClick={() => navigate('services')}
              className="btn-outline px-6 py-3 text-sm self-start md:self-auto whitespace-nowrap"
            >
              {lang === 'ENG' ? 'View All Services →' : 'Xem Tất Cả →'}
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
            {services.map((svc, i) => (
              <div
                key={i}
                className="glass glass-light rounded-2xl p-6 card-hover border border-white/5 cursor-pointer group"
                onClick={() => navigate('services')}
              >
                <div className="mb-5 w-12 h-12 rounded-xl flex items-center justify-center"
                  style={{ background: 'rgba(0,217,255,0.06)', border: '1px solid rgba(0,217,255,0.1)' }}>
                  {svc.icon}
                </div>
                <h3 className="font-display font-bold text-white mb-2 text-base">
                  {lang === 'ENG' ? svc.titleENG : svc.titleVIE}
                </h3>
                <p className="text-white/50 text-sm leading-relaxed">
                  {lang === 'ENG' ? svc.descENG : svc.descVIE}
                </p>
                <div className="mt-4 text-[#00D9FF] text-xs font-mono opacity-0 group-hover:opacity-100 transition-opacity">
                  {lang === 'ENG' ? 'Learn More →' : 'Tìm Hiểu →'}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── FEATURED PROJECTS ── */}
      <section className="py-28 bg-[#0F172A]">
        <div className="max-w-[1400px] mx-auto px-6 md:px-12">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
            <div>
              <div className="section-label mb-4">◆ {tx.projectsTitle}</div>
              <h2 className="font-display text-4xl md:text-5xl font-bold text-white">
                {tx.projectsHeadline}
              </h2>
            </div>
            <button
              onClick={() => navigate('projects')}
              className="btn-outline px-6 py-3 text-sm self-start md:self-auto whitespace-nowrap"
            >
              {tx.viewAll} →
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Large feature */}
            <div
              className="relative overflow-hidden rounded-2xl cursor-pointer group"
              style={{ minHeight: '400px' }}
              onClick={() => navigate('projects')}
            >
              <img
                src={featuredProjects[0].img}
                alt={featuredProjects[0].title}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                style={{ minHeight: '400px' }}
              />
              <div className="absolute inset-0 img-overlay" />
              <div className="absolute inset-0 border border-white/0 group-hover:border-[#00D9FF]/30 rounded-2xl transition-colors duration-300" />
              <div className="absolute bottom-0 left-0 p-8">
                <span className="font-mono text-[10px] tracking-widest text-[#00D9FF] uppercase">
                  {featuredProjects[0].category}
                </span>
                <h3 className="font-display text-3xl font-bold text-white mt-2">{featuredProjects[0].title}</h3>
              </div>
            </div>

            {/* Two stacked */}
            <div className="flex flex-col gap-4">
              {featuredProjects.slice(1).map((proj, i) => (
                <div
                  key={i}
                  className="relative overflow-hidden rounded-2xl cursor-pointer group flex-1"
                  style={{ minHeight: '190px' }}
                  onClick={() => navigate('projects')}
                >
                  <img
                    src={proj.img}
                    alt={proj.title}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    style={{ minHeight: '190px' }}
                  />
                  <div className="absolute inset-0 img-overlay" />
                  <div className="absolute inset-0 border border-white/0 group-hover:border-[#00D9FF]/30 rounded-2xl transition-colors duration-300" />
                  <div className="absolute bottom-0 left-0 p-6">
                    <span className="font-mono text-[10px] tracking-widest text-[#00D9FF] uppercase">
                      {proj.category}
                    </span>
                    <h3 className="font-display text-xl font-bold text-white mt-1">{proj.title}</h3>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── CONTACT CTA ── */}
      <section className="py-32 relative overflow-hidden">
        <div className="absolute inset-0 grid-overlay opacity-50" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] rounded-full opacity-10"
          style={{ background: 'radial-gradient(ellipse, #00D9FF 0%, transparent 70%)' }} />
        <div className="relative max-w-[900px] mx-auto px-6 text-center">
          <div className="section-label mb-6 inline-block">◆ Let's Talk</div>
          <h2 className="font-display text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
            {tx.contactTitle}
          </h2>
          <p className="text-white/50 text-xl mb-10">{tx.contactSub}</p>
          <button className="btn-primary px-12 py-5 text-base font-display font-bold tracking-wide">
            {tx.contactCta}
          </button>
        </div>
      </section>
    </>
  )
}
